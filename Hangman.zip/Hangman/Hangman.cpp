﻿#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <algorithm>
#include <random>
#include <conio.h>

class Word {
protected:
    std::ifstream o;
    std::string word;
    std::vector<std::string> words;
    std::vector<bool> letterIsGuessed;
public:
    Word() {
        o.open("Words.txt");
        std::string line;
        while (std::getline(o, line)) { 
            words.push_back(line);
        }
        ChoiceRandWord();
    }

    void ChoiceRandWord() {
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<>dist(0, 334);
        word = words[dist(gen)];
        letterIsGuessed.resize(word.size());
        for (auto i : letterIsGuessed) { i = false; }
    }
};

class HangMan: Word {
    int lives;
    bool stopGame;
public:
    HangMan() {
        stopGame = false;
        lives = 6;
    }

    void Play() {
        char symbol;
        while (true) {
            std::system("cls");
            std::cout << "Input letter: ";
            std::cin >> symbol;
            checkSymbol(symbol);
            if (stopGame) {
                std::cout << "\nPlay Again?: 1 - Yes; 2 - No..."; 
                std::cin >> symbol;
                switch (symbol)
                {
                case '1':
                    lives = 6;
                    stopGame = false;
                    ChoiceRandWord();
                    break;
                default:
                    exit(0);
                    break;
                }
            }
            std::cout << "\nInput that continue...";
            _getch();
        }
    }

    void checkSymbol(char symbol) {
        if (std::count(word.begin(), word.end(), std::tolower(symbol)) == 0 &&
            std::count(word.begin(), word.end(), std::toupper(symbol)) == 0) {
            std::cout << "This letter is no in the word!\n\n";
            lives--;
        }
        else {
            for (int i = 0; i < word.size(); i++) {
                if ((word[i] == std::tolower(symbol) || word[i] == std::toupper(symbol)) && letterIsGuessed[i]) 
                { std::cout << "This letter is guessed!\n\n"; break; }

                else if ((word[i] == std::tolower(symbol) || word[i] == std::toupper(symbol)) && !letterIsGuessed[i]) 
                { std::cout << "This letter is in the word!\n\n"; letterIsGuessed[i] = true; }
            }
        }
        if (!stopGame) {
            printSymbols();
        }
        printHangMan();
    }

    void printSymbols() {
        for (int i = 0; i < word.size(); i++) {
            if (letterIsGuessed[i]) {
                std::cout << word[i];
                continue;
            }
            std::cout << "_ ";
        }
        std::cout << "\n\n";
        if (std::count(letterIsGuessed.begin(), letterIsGuessed.end(), false) == 0) {
            std::cout << "\nYou are Win!\n";
            stopGame = true;
        }
    }

    void printHangMan() {
        for (int i = 5; i >= lives; i--) {
            switch (i)
            {
            case 5:
                std::cout << "   _____" << std::endl;
                break;
            case 4:
                std::cout << "  |     |" << std::endl;
                break;
            case 3:
                std::cout << "  |     O" << std::endl;
                break;
            case 2:
                std::cout << "  |    /|\\" << std::endl;
                break;
            case 1:
                std::cout << "  |    / \\" << std::endl;
                break;
            default:
                std::cout << "__|________" << std::endl;
                std::cout << "GameOver!\n Your word: " << word;
                stopGame = true;
                break;
            }
        }
    }
};

int main()
{
    srand(time(NULL));
    HangMan hm;
    hm.Play();
}
